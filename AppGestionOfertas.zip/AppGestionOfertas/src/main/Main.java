package main;

import controlador.RegistroPostulaciones;
import modelo.Ofertas;
import modelo.Personal;

public class Main {

    public static void main(String[] args) {
        RegistroPostulaciones oferta = new RegistroPostulaciones();
        
        Ofertas postulacion1 = new Ofertas("Gerente de Negocios", true, "Sebastian Gonzalez", "91364921-3", "seba.gonzalez03@gmail.com", 901234567, true);
        
        
    }
    
}
