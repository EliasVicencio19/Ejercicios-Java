package modelo;

public abstract class Personal {
    protected String nombre,rut, correo;
    protected int telefono;
    protected boolean experiencia;

    public Personal(String nombre, String rut, String correo, int telefono, boolean experiencia) {
        this.nombre = nombre;
        this.rut = rut;
        this.correo = correo;
        this.telefono = telefono;
        this.experiencia = experiencia;
    }

    public Personal() {
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getRut() {
        return rut;
    }

    public void setRut(String rut) {
        this.rut = rut;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public int getTelefono() {
        return telefono;
    }

    public void setTelefono(int telefono) {
        this.telefono = telefono;
    }

    public boolean isExperiencia() {
        return experiencia;
    }

    public void setExperiencia(boolean experiencia) {
        this.experiencia = experiencia;
    }

    @Override
    public String toString() {
        return "Personal{" + "nombre=" + nombre +
                ", rut=" + rut +
                ", correo=" + correo +
                ", telefono=" + telefono +
                ", experiencia=" + experiencia + '}';
    }

    
    
    
}
