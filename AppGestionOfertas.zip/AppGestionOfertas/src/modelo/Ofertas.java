package modelo;

public class Ofertas extends Personal {
    private String puesto;
    private boolean disponibilidadInmediata;

    public Ofertas(String puesto, boolean disponibilidadInmediata, String nombre, String rut, String correo, int telefono, boolean experiencia) {
        super(nombre, rut, correo, telefono, experiencia);
        this.puesto = puesto;
        this.disponibilidadInmediata = disponibilidadInmediata;
    }

    public Ofertas() {
    }

    public String getPuesto() {
        return puesto;
    }

    public void setPuesto(String puesto) {
        this.puesto = puesto;
    }

    public boolean isDisponibilidadInmediata() {
        return disponibilidadInmediata;
    }

    public void setDisponibilidadInmediata(boolean disponibilidadInmediata) {
        this.disponibilidadInmediata = disponibilidadInmediata;
    }

    @Override
    public String toString() {
        return super.toString() + "Ofertas{" + "puesto=" + puesto +
                ", disponibilidadInmediata=" + disponibilidadInmediata + '}';
    }

    
    
    
}
