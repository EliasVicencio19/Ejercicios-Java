package controlador;

import java.util.ArrayList;
import modelo.Ofertas;
import modelo.Personal;

public class RegistroPostulaciones {
    public static ArrayList<Personal> postulaciones = new ArrayList();
    public static ArrayList<Ofertas> ofertas = new ArrayList();
    
    public static boolean agregarPostulacion(Ofertas postulacion) {
        return postulaciones.add(postulacion);
    }
    
    public static Personal buscarPorRut(String rut) {
        for (Personal postulacione : postulaciones) {
            if(postulacione.getRut().equals(rut)) {
                return postulacione;
            }
        }
        return null;
    }
    
    public static boolean eliminarPostulacion(Ofertas postulacion) {
        boolean encontrado = false;
        for (Personal postulacione : postulaciones) {
            if(encontrado == true) {
                postulaciones.remove(ofertas);
            }
        }
        return false;
    }
}
