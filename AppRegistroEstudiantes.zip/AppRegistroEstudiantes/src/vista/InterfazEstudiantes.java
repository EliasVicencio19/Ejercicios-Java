package vista;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

class Estudiante {
    private String nombre;
    private int edad;
    private String id;

    public Estudiante(String nombre, int edad, String id) {
        this.nombre = nombre;
        this.edad = edad;
        this.id = id;
    }

    public String getId() {
        return id;
    }

    public String toString() {
        return "ID: " + id + " - Nombre: " + nombre + " - Edad: " + edad;
    }
}

class GestorEstudiantes {
    private ArrayList<Estudiante> estudiantes = new ArrayList<>();

    public void agregarEstudiante(Estudiante estudiante) {
        estudiantes.add(estudiante);
    }

    public void eliminarEstudiante(String id) {
        estudiantes.removeIf(e -> e.getId().equals(id));
    }

    public ArrayList<Estudiante> obtenerEstudiantes() {
        return estudiantes;
    }
}

public class InterfazEstudiantes {
    private JFrame frame;
    private JTextField txtId, txtNombre, txtEdad;
    private JTextArea txtArea;
    private GestorEstudiantes gestor;

    public InterfazEstudiantes() {
        gestor = new GestorEstudiantes();
        frame = new JFrame("Gestión de Estudiantes");
        frame.setSize(400, 400);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new FlowLayout());

        JLabel lblId = new JLabel("ID:");
        txtId = new JTextField(10);
        JLabel lblNombre = new JLabel("Nombre:");
        txtNombre = new JTextField(10);
        JLabel lblEdad = new JLabel("Edad:");
        txtEdad = new JTextField(5);

        JButton btnAgregar = new JButton("Agregar");
        JButton btnEliminar = new JButton("Eliminar");
        JButton btnListar = new JButton("Listar");

        txtArea = new JTextArea(10, 30);
        txtArea.setEditable(false);

        btnAgregar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    String id = txtId.getText().trim();
                    String nombre = txtNombre.getText().trim();
                    int edad = Integer.parseInt(txtEdad.getText().trim());
                    if (id.isEmpty() || nombre.isEmpty()) {
                        JOptionPane.showMessageDialog(frame, "Los campos no pueden estar vacíos.", "Error",
                                JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                    gestor.agregarEstudiante(new Estudiante(nombre, edad, id));
                    actualizarLista();
                    limpiarCampos();
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(frame, "Ingrese una edad válida.", "Error",
                            JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        btnEliminar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String id = txtId.getText().trim();
                if (id.isEmpty()) {
                    JOptionPane.showMessageDialog(frame, "Ingrese un ID para eliminar.", "Error",
                            JOptionPane.ERROR_MESSAGE);
                    return;
                }
                gestor.eliminarEstudiante(id);
                actualizarLista();
                limpiarCampos();
            }
        });

        btnListar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                actualizarLista();
            }
        });

        frame.add(lblId);
        frame.add(txtId);
        frame.add(lblNombre);
        frame.add(txtNombre);
        frame.add(lblEdad);
        frame.add(txtEdad);
        frame.add(btnAgregar);
        frame.add(btnEliminar);
        frame.add(btnListar);
        frame.add(new JScrollPane(txtArea));

        frame.setVisible(true);
    }

    private void actualizarLista() {
        txtArea.setText("");
        for (Estudiante est : gestor.obtenerEstudiantes()) {
            txtArea.append(est.toString() + "\n");
        }
    }

    private void limpiarCampos() {
        txtId.setText("");
        txtNombre.setText("");
        txtEdad.setText("");
    }

    public static void main(String[] args) {
        new InterfazEstudiantes();
    }
}
