package controlador;

import java.util.ArrayList;

import modelo.Estudiante;

public class GestorEstudiante {
    private ArrayList<Estudiante> estudiantes = new ArrayList<>();

    public boolean agregarEstudiante(Estudiante estudiante) {
        return estudiantes.add(estudiante);
    }

    public void listarEstudiantes() {
        for (Estudiante estudiante : estudiantes) {
            System.out.println(estudiantes);
        }
    }

    public boolean eliminarEstudiante(String id) {
        return estudiantes.remove(id);
    }
}
