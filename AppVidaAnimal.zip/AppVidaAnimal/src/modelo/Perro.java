package modelo;

public class Perro extends Mascota {
    private boolean micro_chip;
    private int f_ultima_vacuna;

    public Perro(boolean micro_chip, int f_ultima_vacuna, String nombre_mascota, int edad, double peso, String raza) {
        super(nombre_mascota, edad, peso, raza);
        this.micro_chip = micro_chip;
        this.f_ultima_vacuna = f_ultima_vacuna;
    }

    public boolean isMicro_chip() {
        return micro_chip;
    }

    public void setMicro_chip(boolean micro_chip) {
        this.micro_chip = micro_chip;
    }

    public int getF_ultima_vacuna() {
        return f_ultima_vacuna;
    }

    public void setF_ultima_vacuna(int f_ultima_vacuna) {
        this.f_ultima_vacuna = f_ultima_vacuna;
    }

    @Override
    public String toString() {
        return "Perro{" + "micro_chip=" + micro_chip + ", f_ultima_vacuna=" + f_ultima_vacuna + '}';
    }
    
    
    
}
