package modelo;

public class Gato extends Mascota{
    private boolean esterilizado;
    private boolean es_interior;

    public Gato(boolean esterilizado, boolean es_interior, String nombre_mascota, int edad, double peso, String raza) {
        super(nombre_mascota, edad, peso, raza);
        this.esterilizado = esterilizado;
        this.es_interior = es_interior;
    }

    public boolean isEsterilizado() {
        return esterilizado;
    }

    public void setEsterilizado(boolean esterilizado) {
        this.esterilizado = esterilizado;
    }

    public boolean isEs_interior() {
        return es_interior;
    }

    public void setEs_interior(boolean es_interior) {
        this.es_interior = es_interior;
    }

    @Override
    public String toString() {
        return "Gato{" + "esterilizado=" + esterilizado + ", es_interior=" + es_interior + '}';
    }
    
    
}
