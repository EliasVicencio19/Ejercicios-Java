package modelo;

public class Consulta {
    private String f_consulta;
    private String propietario;
    private String mascota_atendida;
    private String diagonostico;
    private String tratamiento;
    private double costo;

    public Consulta() {
    }

    public Consulta(String f_consulta, String propietario, String mascota_atendida, String diagonostico, String tratamiento, double costo) {
        this.f_consulta = f_consulta;
        this.propietario = propietario;
        this.mascota_atendida = mascota_atendida;
        this.diagonostico = diagonostico;
        this.tratamiento = tratamiento;
        this.costo = costo;
    }

    public String getF_consulta() {
        return f_consulta;
    }

    public void setF_consulta(String f_consulta) {
        this.f_consulta = f_consulta;
    }

    public String getPropietario() {
        return propietario;
    }

    public void setPropietario(String propietario) {
        this.propietario = propietario;
    }

    public String getMascota_atendida() {
        return mascota_atendida;
    }

    public void setMascota_atendida(String mascota_atendida) {
        this.mascota_atendida = mascota_atendida;
    }

    public String getDiagonostico() {
        return diagonostico;
    }

    public void setDiagonostico(String diagonostico) {
        this.diagonostico = diagonostico;
    }

    public String getTratamiento() {
        return tratamiento;
    }

    public void setTratamiento(String tratamiento) {
        this.tratamiento = tratamiento;
    }

    public double getCosto() {
        return costo;
    }

    public void setCosto(double costo) {
        this.costo = costo;
    }

    @Override
    public String toString() {
        return "Consulta{" + "f_consulta=" + f_consulta + ", propietario=" + propietario + ", mascota_atendida=" + mascota_atendida + ", diagonostico=" + diagonostico + ", tratamiento=" + tratamiento + ", costo=" + costo + '}';
    }
    
    
}
