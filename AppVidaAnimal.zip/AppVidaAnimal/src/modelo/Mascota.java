package modelo;

public abstract class Mascota {
    protected String nombre_mascota;
    protected int edad;
    protected double peso;
    protected String raza;

    public Mascota(String nombre_mascota, int edad, double peso, String raza) {
        this.nombre_mascota = nombre_mascota;
        this.edad = edad;
        this.peso = peso;
        this.raza = raza;
    }

    public Mascota() {
    }

    public String getNombre_mascota() {
        return nombre_mascota;
    }

    public void setNombre_mascota(String nombre_mascota) {
        this.nombre_mascota = nombre_mascota;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public double getPeso() {
        return peso;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }

    public String getRaza() {
        return raza;
    }

    public void setRaza(String raza) {
        this.raza = raza;
    }

    @Override
    public String toString() {
        return "Mascota{" + "nombre_mascota=" + nombre_mascota + ", edad=" + edad + ", peso=" + peso + ", raza=" + raza + '}';
    }

    
    
    
}
